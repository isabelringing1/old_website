A Javascript clone of nowykurier's Gravity Toy.

#TODO:
- [ ] Allow text entry of particle size
- [ ] Create more detailed instructions
- [x] Enable particle translation

Files minimized with minifier from npm.
